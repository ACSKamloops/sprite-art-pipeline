"""Versioned local sprite workflow services; no implicit remote inference."""
__version__ = "0.1.0"
